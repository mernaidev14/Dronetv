import { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";
import { Edit3, Check, X } from "lucide-react";

interface EditableTextProps {
  initialText: string;
  className?: string;
  tag?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span' | 'div';
  placeholder?: string;
  multiline?: boolean;
  onSave?: (text: string) => void;
}

export function EditableText({ 
  initialText, 
  className = "", 
  tag = 'p', 
  placeholder = "Enter text...",
  multiline = false,
  onSave
}: EditableTextProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [text, setText] = useState(initialText);
  const [tempText, setTempText] = useState(initialText);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    setText(tempText);
    setIsEditing(false);
    onSave?.(tempText);
  };

  const handleCancel = () => {
    setTempText(text);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !multiline) {
      e.preventDefault();
      handleSave();
    } else if (e.key === 'Enter' && e.ctrlKey && multiline) {
      e.preventDefault();
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  const Component = tag as keyof JSX.IntrinsicElements;

  if (isEditing) {
    const InputComponent = multiline ? 'textarea' : 'input';
    
    return (
      <motion.div 
        className="relative group"
        initial={{ scale: 0.98 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.2 }}
      >
        <InputComponent
          ref={inputRef as any}
          value={tempText}
          onChange={(e) => setTempText(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={handleSave}
          placeholder={placeholder}
          className={`${className} bg-input-background border-2 border-primary/50 rounded-md px-2 py-1 outline-none resize-none w-full transition-colors duration-200 focus:border-primary`}
          rows={multiline ? 3 : undefined}
        />
        
        {/* Edit controls */}
        <div className="absolute -right-16 top-0 flex items-center space-x-1 opacity-100">
          <motion.button
            onClick={handleSave}
            className="p-1 rounded bg-green-500 text-white hover:bg-green-600 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Check size={12} />
          </motion.button>
          <motion.button
            onClick={handleCancel}
            className="p-1 rounded bg-red-500 text-white hover:bg-red-600 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <X size={12} />
          </motion.button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      className="relative group cursor-pointer"
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.2 }}
    >
      <Component
        className={`${className} transition-all duration-200 hover:bg-primary/5 rounded px-1 py-0.5 relative`}
        onClick={() => setIsEditing(true)}
      >
        {text || placeholder}
        
        {/* Edit icon */}
        <motion.div
          className="absolute -right-6 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
          initial={{ opacity: 0, x: -10 }}
          whileHover={{ opacity: 1, x: 0 }}
        >
          <Edit3 size={14} className="text-primary/70" />
        </motion.div>
      </Component>
    </motion.div>
  );
}

export default EditableText;