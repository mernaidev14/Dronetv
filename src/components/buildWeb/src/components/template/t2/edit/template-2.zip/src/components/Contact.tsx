import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { motion } from "motion/react";
import EditableText from "./EditableText";

export default function Contact() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const contactInfo = [
    {
      icon: Clock,
      title: "Business Hours",
      primary: "Mon - Fri: 9:00 AM - 6:00 PM EST",
      secondary: "Sat: 10:00 AM - 2:00 PM EST",
      color: "red-accent"
    }
  ];

  return (
    <motion.section 
      id="contact" 
      className="py-20 bg-secondary theme-transition"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, type: "spring" }}
          >
            <EditableText 
              initialText="Get In Touch"
              className="text-3xl md:text-4xl text-foreground mb-4"
              tag="h2"
            />
          </motion.div>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <EditableText 
              initialText="Ready to transform your business? Let's start a conversation about how we can help you achieve your goals with our "
              className="text-lg text-muted-foreground inline"
              tag="p"
              multiline
            />
            <motion.span 
              className="text-red-accent font-semibold"
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <EditableText 
                initialText="expert solutions"
                className="text-lg text-red-accent font-semibold"
                tag="span"
              />
            </motion.span>
            <EditableText 
              initialText="."
              className="text-lg text-muted-foreground"
              tag="span"
            />
          </motion.div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <Card className="bg-card border-border relative overflow-hidden hover-lift">
              {/* Form header accent */}
              <motion.div 
                className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-accent to-primary"
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5, duration: 1 }}
              />
              
              <CardHeader>
                <CardTitle className="text-card-foreground">
                  <EditableText 
                    initialText="Send us a message"
                    className="text-card-foreground"
                    tag="span"
                  />
                </CardTitle>
                <EditableText 
                  initialText="We'll get back to you within 24 hours during business days."
                  className="text-sm text-muted-foreground"
                  tag="p"
                />
              </CardHeader>
              <CardContent className="space-y-6">
                <motion.div 
                  className="grid grid-cols-2 gap-4"
                  variants={containerVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <motion.div className="space-y-2" variants={itemVariants}>
                    <Label htmlFor="firstName">
                      <EditableText 
                        initialText="First Name"
                        className="text-sm font-medium text-card-foreground"
                        tag="span"
                      />
                    </Label>
                    <motion.div
                      whileFocus={{ scale: 1.02 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Input 
                        id="firstName" 
                        placeholder="John" 
                        className="border-border focus:border-primary transition-all duration-300 bg-input-background" 
                      />
                    </motion.div>
                  </motion.div>
                  <motion.div className="space-y-2" variants={itemVariants}>
                    <Label htmlFor="lastName">
                      <EditableText 
                        initialText="Last Name"
                        className="text-sm font-medium text-card-foreground"
                        tag="span"
                      />
                    </Label>
                    <motion.div
                      whileFocus={{ scale: 1.02 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Input 
                        id="lastName" 
                        placeholder="Doe" 
                        className="border-border focus:border-primary transition-all duration-300 bg-input-background" 
                      />
                    </motion.div>
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="space-y-2"
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <Label htmlFor="email">
                    <EditableText 
                      initialText="Email"
                      className="text-sm font-medium text-card-foreground"
                      tag="span"
                    />
                  </Label>
                  <motion.div
                    whileFocus={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="john@company.com" 
                      className="border-border focus:border-primary transition-all duration-300 bg-input-background" 
                    />
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="space-y-2"
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <Label htmlFor="company">
                    <EditableText 
                      initialText="Company"
                      className="text-sm font-medium text-card-foreground"
                      tag="span"
                    />
                  </Label>
                  <motion.div
                    whileFocus={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Input 
                      id="company" 
                      placeholder="Your Company" 
                      className="border-border focus:border-primary transition-all duration-300 bg-input-background" 
                    />
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="space-y-2"
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <Label htmlFor="subject">
                    <EditableText 
                      initialText="Subject"
                      className="text-sm font-medium text-card-foreground"
                      tag="span"
                    />
                  </Label>
                  <motion.select 
                    className="w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300 bg-input-background text-card-foreground"
                    whileFocus={{ scale: 1.02 }}
                  >
                    <option>General Inquiry</option>
                    <option>Strategy Consulting</option>
                    <option>Team Development</option>
                    <option>Digital Transformation</option>
                    <option>Performance Optimization</option>
                  </motion.select>
                </motion.div>

                <motion.div 
                  className="space-y-2"
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <Label htmlFor="message">
                    <EditableText 
                      initialText="Message"
                      className="text-sm font-medium text-card-foreground"
                      tag="span"
                    />
                  </Label>
                  <motion.div
                    whileFocus={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Textarea 
                      id="message" 
                      placeholder="Tell us about your project and how we can help..."
                      className="min-h-[120px] border-border focus:border-primary transition-all duration-300 bg-input-background"
                    />
                  </motion.div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg hover:shadow-xl transition-all duration-300">
                    <motion.span
                      animate={{ opacity: [1, 0.8, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <EditableText 
                        initialText="Send Message"
                        className="font-medium text-primary-foreground"
                        tag="span"
                      />
                    </motion.span>
                  </Button>
                </motion.div>

                <motion.div 
                  className="text-center"
                  variants={itemVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <EditableText 
                    initialText="We typically respond within 24 hours during business days."
                    className="text-sm text-muted-foreground"
                    tag="p"
                  />
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Information */}
          <motion.div 
            className="space-y-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {contactInfo.map((info, index) => {
              const IconComponent = info.icon;
              return (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ scale: 1.02, x: 10 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="bg-card border-border hover-lift cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <motion.div 
                          className={`w-12 h-12 bg-${info.color}/10 rounded-lg flex items-center justify-center flex-shrink-0`}
                          whileHover={{ 
                            scale: 1.2, 
                            rotate: 360,
                            transition: { duration: 0.6 }
                          }}
                        >
                          <IconComponent className={`h-6 w-6 text-${info.color}`} />
                        </motion.div>
                        <div>
                          <motion.div
                            whileHover={{ color: "var(--color-primary)" }}
                          >
                            <EditableText 
                              initialText={info.title}
                              className="font-medium text-card-foreground mb-1"
                              tag="h4"
                            />
                          </motion.div>
                          <EditableText 
                            initialText={info.primary}
                            className="text-muted-foreground"
                            tag="p"
                          />
                          <EditableText 
                            initialText={info.secondary}
                            className="text-muted-foreground text-sm"
                            tag="p"
                          />
                          <EditableText 
                            initialText="Closed on Sundays"
                            className="text-muted-foreground"
                            tag="p"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}

            {/* Contact CTA card */}
            <motion.div
              variants={itemVariants}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground hover-lift">
                <CardContent className="p-6 text-center">
                  <motion.div
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <EditableText 
                      initialText="Ready to Get Started?"
                      className="font-bold mb-2 text-primary-foreground"
                      tag="h4"
                    />
                  </motion.div>
                  <EditableText 
                    initialText="Schedule a free consultation to discuss your business needs"
                    className="text-sm mb-4 opacity-90 text-primary-foreground"
                    tag="p"
                    multiline
                  />
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button className="bg-red-accent text-white hover:bg-red-accent/90 font-bold shadow-lg">
                      <EditableText 
                        initialText="Book Free Consultation"
                        className="font-bold text-white"
                        tag="span"
                      />
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}