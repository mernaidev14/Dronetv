import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Monitor, Smartphone, Cloud, BarChart3, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion } from "motion/react";
import EditableText from "./EditableText";

export default function Product() {
  const products = [
    {
      icon: Monitor,
      title: "Business Dashboard Pro",
      category: "Analytics Platform",
      image: "https://images.unsplash.com/photo-1575388902449-6bca946ad549?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRhc2hib2FyZCUyMGludGVyZmFjZXxlbnwxfHx8fDE3NTU2NzIwNzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Real-time business intelligence dashboard with comprehensive performance metrics.",
      features: ["Real-time Analytics", "Custom Reports", "Data Visualization", "Multi-platform Support"],
      isPopular: true,
      categoryColor: "bg-blue-100 text-blue-800"
    },
    {
      icon: Smartphone,
      title: "Mobile Workforce App",
      category: "Mobile Solution",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkZXZlbG9wbWVudHxlbnwxfHx8fDE3NTU2NjMwNDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Comprehensive mobile solution for remote team management and collaboration.",
      features: ["Team Communication", "Task Management", "Time Tracking", "GPS Services"],
      isPopular: false,
      categoryColor: "bg-green-100 text-green-800"
    },
    {
      icon: Cloud,
      title: "Cloud Infrastructure Suite",
      category: "Cloud Platform",
      image: "https://images.unsplash.com/photo-1676378280996-cff6b481d701?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG91ZCUyMGNvbXB1dGluZyUyMGluZnJhc3RydWN0dXJlfGVufDF8fHx8MTc1NTYwMzQ5MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Scalable cloud infrastructure with enterprise-grade security and reliability.",
      features: ["Auto-scaling", "Advanced Security", "99.9% Uptime", "24/7 Monitoring"],
      isPopular: false,
      categoryColor: "bg-purple-100 text-purple-800"
    },
    {
      icon: BarChart3,
      title: "Advanced Analytics Engine",
      category: "Data Intelligence",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwdmlzdWFsaXphdGlvbnxlbnwxfHx8fDE3NTU2MzQ2NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description: "Powerful analytics engine with predictive insights and machine learning capabilities.",
      features: ["Predictive Analytics", "ML Models", "Big Data Processing", "Custom Algorithms"],
      isPopular: false,
      categoryColor: "bg-orange-100 text-orange-800"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { y: 100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <motion.section 
      id="product" 
      className="py-20 bg-secondary theme-transition"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div 
            className="inline-flex items-center px-4 py-2 bg-red-accent/10 rounded-full text-red-accent mb-4"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Zap className="w-4 h-4 mr-2" />
            <EditableText 
              initialText="Our Products"
              className="font-medium"
              tag="span"
            />
          </motion.div>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <EditableText 
              initialText="Innovative Solutions Built for Success"
              className="text-3xl md:text-4xl text-foreground mb-4"
              tag="h2"
            />
          </motion.div>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <EditableText 
              initialText="Discover our suite of cutting-edge products designed to streamline operations, boost productivity, and drive "
              className="text-lg text-muted-foreground inline"
              tag="p"
              multiline
            />
            <motion.span 
              className="text-primary font-semibold"
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <EditableText 
                initialText="exceptional results"
                className="text-lg text-primary font-semibold"
                tag="span"
              />
            </motion.span>
            <EditableText 
              initialText=" for your business."
              className="text-lg text-muted-foreground"
              tag="span"
            />
          </motion.div>
        </motion.div>

        {/* Products Grid */}
        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {products.map((product, index) => {
            const IconComponent = product.icon;
            return (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover={{ y: -5 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="group h-full hover:shadow-xl transition-all duration-300 border-border hover:border-red-accent/30 relative overflow-hidden cursor-pointer">
                  {/* Image Header */}
                  <div className="relative h-32 overflow-hidden">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      transition={{ duration: 0.4 }}
                      className="h-full"
                    >
                      <ImageWithFallback
                        src={product.image}
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                    </motion.div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                    
                    {/* Category Tag */}
                    <motion.div
                      className="absolute top-2 left-2"
                      initial={{ scale: 0, opacity: 0 }}
                      whileInView={{ scale: 1, opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 + 0.3, duration: 0.4 }}
                    >
                      <Badge className={`${product.categoryColor} border-0 text-xs`}>
                        <EditableText 
                          initialText={product.category}
                          className="text-xs"
                          tag="span"
                        />
                      </Badge>
                    </motion.div>

                    {/* Popular Badge */}
                    {product.isPopular && (
                      <motion.div 
                        className="absolute top-2 right-2 bg-red-accent text-white px-2 py-1 rounded-full text-xs font-bold flex items-center"
                        initial={{ scale: 0, rotate: -180 }}
                        whileInView={{ scale: 1, rotate: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + 0.5, duration: 0.4, type: "spring" }}
                        whileHover={{ scale: 1.05 }}
                      >
                        <Zap className="w-2 h-2 mr-1" />
                        <EditableText 
                          initialText="Bestseller"
                          className="text-xs font-bold text-white"
                          tag="span"
                        />
                      </motion.div>
                    )}

                    {/* Icon Overlay */}
                    <motion.div 
                      className="absolute bottom-2 left-2"
                      whileHover={{ 
                        scale: 1.1, 
                        rotate: 360,
                        transition: { duration: 0.5 }
                      }}
                    >
                      <div className={`w-8 h-8 ${product.isPopular ? 'bg-red-accent/90' : 'bg-primary/90'} rounded-lg flex items-center justify-center backdrop-blur-sm`}>
                        <IconComponent className="h-4 w-4 text-white" />
                      </div>
                    </motion.div>
                  </div>
                  
                  <CardHeader className="pb-2">
                    <CardTitle className={`text-card-foreground group-hover:${product.isPopular ? 'text-red-accent' : 'text-primary'} transition-colors duration-300 text-base`}>
                      <EditableText 
                        initialText={product.title}
                        className={`text-card-foreground group-hover:${product.isPopular ? 'text-red-accent' : 'text-primary'} transition-colors duration-300 text-base`}
                        tag="span"
                      />
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="space-y-3">
                    <EditableText 
                      initialText={product.description}
                      className="text-sm text-muted-foreground leading-relaxed"
                      tag="p"
                      multiline
                    />
                    
                    <motion.ul 
                      className="space-y-1"
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 + 0.5 }}
                    >
                      {product.features.map((feature, featureIndex) => (
                        <motion.li 
                          key={featureIndex} 
                          className="text-xs text-muted-foreground flex items-center"
                          initial={{ x: -10, opacity: 0 }}
                          whileInView={{ x: 0, opacity: 1 }}
                          viewport={{ once: true }}
                          transition={{ delay: index * 0.1 + featureIndex * 0.05 + 0.6 }}
                        >
                          <motion.div 
                            className={`w-1 h-1 ${product.isPopular ? 'bg-red-accent' : 'bg-primary'} rounded-full mr-2 flex-shrink-0`}
                            whileHover={{ scale: 1.5 }}
                            transition={{ type: "spring", stiffness: 400 }}
                          />
                          <EditableText 
                            initialText={feature}
                            className="text-xs text-muted-foreground"
                            tag="span"
                          />
                        </motion.li>
                      ))}
                    </motion.ul>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Product Benefits */}
        <motion.div 
          className="mt-16 grid md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {[
            { icon: "30", color: "red-accent", title: "30-Day Free Trial", desc: "Try all features risk-free with our comprehensive trial period." },
            { icon: "99%", color: "primary", title: "99% Uptime Guarantee", desc: "Enterprise-grade reliability with industry-leading uptime SLA." },
            { icon: "∞", color: "gradient", title: "Unlimited Scalability", desc: "Grow without limits with our cloud-native architecture." }
          ].map((benefit, index) => (
            <motion.div 
              key={index}
              className="text-center group cursor-pointer"
              variants={cardVariants}
              whileHover={{ y: -3 }}
            >
              <motion.div 
                className={`w-10 h-10 ${benefit.color === 'gradient' ? 'bg-gradient-to-r from-red-accent to-primary' : `bg-${benefit.color}`} rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform`}
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                <EditableText 
                  initialText={benefit.icon}
                  className={`${benefit.color === 'red-accent' ? 'text-white' : 'text-black'} font-bold text-sm`}
                  tag="span"
                />
              </motion.div>
              <EditableText 
                initialText={benefit.title}
                className="font-semibold text-foreground mb-2 text-sm"
                tag="h4"
              />
              <EditableText 
                initialText={benefit.desc}
                className="text-muted-foreground text-xs leading-relaxed"
                tag="p"
                multiline
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  );
}