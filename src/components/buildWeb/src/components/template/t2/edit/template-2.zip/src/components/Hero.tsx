import { Button } from "./ui/button";
import { ArrowRight, Play, CheckCircle } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion } from "motion/react";
import EditableText from "./EditableText";

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const floatingVariants = {
    animate: {
      y: [-10, 10, -10],
      transition: {
        duration: 4,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <section id="home" className="pt-20 pb-16 bg-background relative overflow-hidden theme-transition">
      {/* Animated background decorations */}
      <motion.div 
        className="absolute top-20 right-0 w-72 h-72 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2"
        animate={{
          scale: [1, 1.1, 1],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      <motion.div 
        className="absolute bottom-0 left-0 w-96 h-96 bg-primary/3 rounded-full translate-y-1/2 -translate-x-1/2"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, -180, -360]
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      <motion.div 
        className="absolute top-40 right-20 w-20 h-20 bg-red-accent/10 rounded-full"
        variants={floatingVariants}
        animate="animate"
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div 
            className="space-y-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <div className="space-y-4">
              <motion.div 
                className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary border border-primary/20 mb-4"
                variants={itemVariants}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                <EditableText 
                  initialText="Trusted by 500+ Companies"
                  className="font-medium text-sm"
                  tag="span"
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <EditableText 
                  initialText="Transform Your Business with "
                  className="text-4xl md:text-6xl text-foreground leading-tight inline"
                  tag="h1"
                />
                <motion.span 
                  className="text-primary relative"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <EditableText 
                    initialText="Innovation"
                    className="text-4xl md:text-6xl text-primary leading-tight"
                    tag="span"
                  />
                  <motion.svg 
                    className="absolute -bottom-2 left-0 w-full h-3 text-primary/30" 
                    viewBox="0 0 100 12" 
                    fill="none" 
                    xmlns="http://www.w3.org/2000/svg"
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{ duration: 2, delay: 1 }}
                  >
                    <motion.path 
                      d="M0 8C20 4 40 0 60 2C80 4 100 8 100 8V12H0V8Z" 
                      fill="currentColor"
                    />
                  </motion.svg>
                </motion.span>
              </motion.div>

              <motion.div variants={itemVariants}>
                <EditableText 
                  initialText="We help companies scale and grow with cutting-edge solutions, expert guidance, and proven strategies that deliver "
                  className="text-xl text-muted-foreground max-w-lg inline"
                  tag="p"
                  multiline
                />
                <motion.span 
                  className="text-red-accent font-semibold"
                  whileHover={{ scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <EditableText 
                    initialText="exceptional results"
                    className="text-xl text-red-accent font-semibold"
                    tag="span"
                  />
                </motion.span>
                <EditableText 
                  initialText="."
                  className="text-xl text-muted-foreground"
                  tag="span"
                />
              </motion.div>
            </div>

            {/* CTA Buttons */}
            <motion.div 
              className="flex flex-col sm:flex-row gap-4"
              variants={itemVariants}
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-xl hover:shadow-2xl transition-all duration-300">
                  <EditableText 
                    initialText="Get Started Today"
                    className="font-medium"
                    tag="span"
                  />
                  <motion.div
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </motion.div>
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300">
                  <Play className="mr-2 h-5 w-5" />
                  <EditableText 
                    initialText="Watch Demo"
                    className="font-medium"
                    tag="span"
                  />
                </Button>
              </motion.div>
            </motion.div>

            {/* Trust indicators */}
            <motion.div 
              className="flex items-center space-x-6 pt-4"
              variants={itemVariants}
            >
              <div className="flex items-center space-x-2">
                <div className="flex -space-x-2">
                  <motion.div 
                    className="w-8 h-8 bg-primary rounded-full border-2 border-background"
                    whileHover={{ scale: 1.2, zIndex: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  />
                  <motion.div 
                    className="w-8 h-8 bg-primary/80 rounded-full border-2 border-background"
                    whileHover={{ scale: 1.2, zIndex: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  />
                  <motion.div 
                    className="w-8 h-8 bg-red-accent rounded-full border-2 border-background"
                    whileHover={{ scale: 1.2, zIndex: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  />
                </div>
                <EditableText 
                  initialText="Join 500+ satisfied clients"
                  className="text-sm text-muted-foreground"
                  tag="span"
                />
              </div>
            </motion.div>

            {/* Stats */}
            <motion.div 
              className="grid grid-cols-3 gap-8 pt-8"
              variants={itemVariants}
            >
              {[
                { value: "500+", label: "Happy Clients", color: "red-accent" },
                { value: "95%", label: "Success Rate", color: "red-accent" },
                { value: "24/7", label: "Support", color: "primary" }
              ].map((stat, index) => (
                <motion.div 
                  key={index}
                  className="group cursor-pointer"
                  whileHover={{ scale: 1.05 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.5 + index * 0.2 }}
                >
                  <motion.div 
                    className={`text-2xl font-bold text-foreground group-hover:text-${stat.color} transition-colors`}
                    whileHover={{ scale: 1.1 }}
                  >
                    <EditableText 
                      initialText={stat.value}
                      className={`text-2xl font-bold text-foreground group-hover:text-${stat.color} transition-colors`}
                      tag="div"
                    />
                  </motion.div>
                  <EditableText 
                    initialText={stat.label}
                    className="text-muted-foreground"
                    tag="div"
                  />
                  <motion.div 
                    className={`w-8 h-1 bg-${stat.color}/30 group-hover:bg-${stat.color} transition-colors mt-1`}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.3 }}
                  />
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Hero Image */}
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <motion.div 
              className="relative rounded-2xl overflow-hidden shadow-2xl hover-lift"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1698047682129-c3e217ac08b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBidXNpbmVzcyUyMHRlYW0lMjBvZmZpY2V8ZW58MXx8fHwxNzU1NjE4MzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Modern business team collaborating"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              
              {/* Image overlay decorations */}
              <motion.div 
                className="absolute top-4 right-4 w-16 h-16 bg-primary/20 rounded-full backdrop-blur-sm"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute top-4 left-4 w-12 h-12 bg-red-accent/20 rounded-full backdrop-blur-sm"
                variants={floatingVariants}
                animate="animate"
              />
            </motion.div>
            
            {/* Floating cards */}
            <motion.div 
              className="absolute -bottom-6 -left-6 bg-card p-6 rounded-xl shadow-lg border border-border hover-lift"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5, duration: 0.8 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="flex items-center space-x-3">
                <motion.div 
                  className="w-3 h-3 bg-primary rounded-full"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <EditableText 
                  initialText="Live Support Available"
                  className="text-sm font-medium text-card-foreground"
                  tag="span"
                />
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}