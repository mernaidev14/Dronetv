
  # template-2

  This is a code bundle for template-2. The original project is available at https://www.figma.com/design/wKrr2lsfG7xZqA8kanqCCj/template-2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  