import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Lightbulb,
  Users,
  Zap,
  Target,
  Star,
  ArrowRight,
  Filter,
  X,
  CheckCircle,
  Clock,
  DollarSign,
  Calendar,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion, AnimatePresence } from "motion/react";
import { useState, useMemo } from "react";
import EditableText from "./EditableText";

export default function Services() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedService, setSelectedService] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const services = [
    {
      icon: Lightbulb,
      title: "Strategy Consulting",
      category: "Business Strategy",
      image:
        "https://images.unsplash.com/photo-1565688527174-775059ac429c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHN0cmF0ZWd5JTIwY29uc3VsdGluZyUyMG1lZXRpbmd8ZW58MXx8fHwxNzU1Njc3NjA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description:
        "Comprehensive business strategy development to drive growth and competitive advantage.",
      features: [
        "Market Analysis",
        "Strategic Planning",
        "Risk Assessment",
      ],
      isPopular: false,
      categoryColor: "bg-blue-100 text-blue-800",
      detailedDescription: "Our strategy consulting service helps businesses navigate complex challenges and opportunities. We provide in-depth market analysis, develop comprehensive strategic plans, and conduct thorough risk assessments to ensure your business is positioned for success in today's competitive landscape.",
      benefits: [
        "Increased market share",
        "Improved competitive positioning",
        "Enhanced operational efficiency",
        "Better risk management"
      ],
      process: [
        "Initial consultation & assessment",
        "Market research & analysis",
        "Strategy development",
        "Implementation planning",
        "Ongoing support & optimization"
      ],
      pricing: "Custom quotes based on project scope",
      timeline: "4-12 weeks depending on complexity"
    },
    {
      icon: Users,
      title: "Team Development",
      category: "Human Resources",
      image:
        "https://images.unsplash.com/photo-1646579886135-068c73800308?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwZGV2ZWxvcG1lbnQlMjB0cmFpbmluZyUyMHdvcmtzaG9wfGVufDF8fHx8MTc1NTYwNzA3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description:
        "Expert training programs and leadership development for high-performing teams.",
      features: [
        "Leadership Training",
        "Skills Development",
        "Team Building",
      ],
      isPopular: true,
      categoryColor: "bg-green-100 text-green-800",
      detailedDescription: "Transform your team into a high-performing unit with our comprehensive development programs. We focus on leadership training, skill enhancement, and team building activities that foster collaboration and drive results.",
      benefits: [
        "Enhanced team collaboration",
        "Improved leadership skills",
        "Increased employee engagement",
        "Higher productivity levels"
      ],
      process: [
        "Skills gap analysis",
        "Customized training program design",
        "Interactive workshop delivery",
        "Progress tracking & assessment",
        "Continuous improvement plans"
      ],
      pricing: "From $2,500 per team",
      timeline: "2-8 weeks program duration"
    },
    {
      icon: Zap,
      title: "Digital Transformation",
      category: "Technology",
      image:
        "https://images.unsplash.com/photo-1623578240928-9473b76272ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwdHJhbnNmb3JtYXRpb24lMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1NTYxNDMxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description:
        "Modernize operations with cutting-edge technology and automation solutions.",
      features: [
        "Process Automation",
        "Cloud Migration",
        "Digital Strategy",
      ],
      isPopular: false,
      categoryColor: "bg-purple-100 text-purple-800",
      detailedDescription: "Embrace the future with our digital transformation services. We help businesses modernize their operations through process automation, cloud migration, and comprehensive digital strategy development.",
      benefits: [
        "Reduced operational costs",
        "Improved efficiency through automation",
        "Enhanced scalability with cloud solutions",
        "Future-proof technology infrastructure"
      ],
      process: [
        "Digital maturity assessment",
        "Technology stack evaluation",
        "Implementation roadmap creation",
        "System integration & migration",
        "Training & ongoing support"
      ],
      pricing: "Project-based pricing starting at $15,000",
      timeline: "8-24 weeks implementation"
    },
    {
      icon: Target,
      title: "Performance Optimization",
      category: "Analytics",
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJmb3JtYW5jZSUyMGFuYWx5dGljcyUyMGRhc2hib2FyZHxlbnwxfHx8fDE3NTU2Nzc2MDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      description:
        "Data-driven insights and KPI tracking to maximize business performance.",
      features: [
        "Analytics Setup",
        "KPI Tracking",
        "ROI Optimization",
      ],
      isPopular: false,
      categoryColor: "bg-orange-100 text-orange-800",
      detailedDescription: "Leverage data to drive business decisions with our performance optimization services. We set up comprehensive analytics systems, implement KPI tracking, and optimize ROI across all business functions.",
      benefits: [
        "Data-driven decision making",
        "Improved ROI on marketing spend",
        "Enhanced operational visibility",
        "Proactive performance management"
      ],
      process: [
        "Current performance assessment",
        "KPI framework development",
        "Analytics system implementation",
        "Dashboard creation & training",
        "Ongoing optimization & reporting"
      ],
      pricing: "Monthly packages from $1,500",
      timeline: "4-8 weeks initial setup"
    },
  ];

  // Get all unique categories
  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(services.map(service => service.category))];
    return ["All", ...uniqueCategories];
  }, [services]);

  // Filter services based on active category
  const filteredServices = useMemo(() => {
    if (activeCategory === "All") return services;
    return services.filter(service => service.category === activeCategory);
  }, [activeCategory, services]);

  const openModal = (service) => {
    setSelectedService(service);
    setIsModalOpen(true);
    document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedService(null);
    document.body.style.overflow = 'auto'; // Re-enable scrolling
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const cardVariants = {
    hidden: { y: 100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  return (
    <motion.section
      id="services"
      className="py-20 bg-background theme-transition"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary mb-4"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <EditableText 
              initialText="Our Services"
              className="font-medium"
              tag="span"
            />
          </motion.div>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <EditableText 
              initialText="Comprehensive Solutions for Your Business"
              className="text-3xl md:text-4xl text-foreground mb-4"
              tag="h2"
            />
          </motion.div>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <EditableText 
              initialText="We offer comprehensive solutions to help your business thrive in today's competitive landscape with our expert services and "
              className="text-lg text-muted-foreground inline"
              tag="p"
              multiline
            />
            <motion.span
              className="text-red-accent font-semibold"
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <EditableText 
                initialText="proven methodologies"
                className="text-lg text-red-accent font-semibold"
                tag="span"
              />
            </motion.span>
            <EditableText 
              initialText="."
              className="text-lg text-muted-foreground"
              tag="span"
            />
          </motion.div>
        </motion.div>

        {/* Category Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-3 mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="w-full flex items-center justify-center mb-4">
            <Filter className="h-5 w-5 text-muted-foreground mr-2" />
            <EditableText 
              initialText="Filter by category:"
              className="text-sm font-medium text-muted-foreground"
              tag="span"
            />
          </div>
          
          {categories.map((category) => (
            <motion.div
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                variant={activeCategory === category ? "default" : "outline"}
                className={`rounded-full text-sm px-4 py-2 ${activeCategory === category ? "bg-primary text-primary-foreground" : "bg-card text-card-foreground border-border hover:bg-secondary"}`}
                onClick={() => setActiveCategory(category)}
              >
                <EditableText 
                  initialText={category}
                  className="font-medium"
                  tag="span"
                />
              </Button>
            </motion.div>
          ))}
        </motion.div>

        {/* Services Grid */}
        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          key={activeCategory} // Re-animate when category changes
        >
          {filteredServices.length > 0 ? (
            filteredServices.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <motion.div
                  key={index}
                  variants={cardVariants}
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="group h-full hover:shadow-xl transition-all duration-300 border-border hover:border-primary/30 relative overflow-hidden cursor-pointer">
                    {/* Image Header */}
                    <div className="relative h-32 overflow-hidden">
                      <motion.div
                        whileHover={{ scale: 1.05 }}
                        transition={{ duration: 0.4 }}
                        className="h-full"
                      >
                        <ImageWithFallback
                          src={service.image}
                          alt={service.title}
                          className="w-full h-full object-cover"
                        />
                      </motion.div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />

                      {/* Category Tag */}
                      <motion.div
                        className="absolute top-2 left-2"
                        initial={{ scale: 0, opacity: 0 }}
                        whileInView={{ scale: 1, opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{
                          delay: index * 0.1 + 0.3,
                          duration: 0.4,
                        }}
                      >
                        <Badge
                          className={`${service.categoryColor} border-0 text-xs`}
                        >
                          <EditableText 
                            initialText={service.category}
                            className="text-xs"
                            tag="span"
                          />
                        </Badge>
                      </motion.div>

                      {/* Popular Badge */}
                      {service.isPopular && (
                        <motion.div
                          className="absolute top-2 right-2 bg-red-accent text-white px-2 py-1 rounded-full text-xs font-bold flex items-center"
                          initial={{ scale: 0, rotate: -180 }}
                          whileInView={{ scale: 1, rotate: 0 }}
                          viewport={{ once: true }}
                          transition={{
                            delay: index * 0.1 + 0.5,
                            duration: 0.4,
                            type: "spring",
                          }}
                          whileHover={{ scale: 1.05 }}
                        >
                          <Star className="w-2 h-2 mr-1" />
                          <EditableText 
                            initialText="Popular"
                            className="text-xs font-bold text-white"
                            tag="span"
                          />
                        </motion.div>
                      )}

                      {/* Icon Overlay */}
                      <motion.div
                        className="absolute bottom-2 left-2"
                        whileHover={{
                          scale: 1.1,
                          rotate: 360,
                          transition: { duration: 0.5 },
                        }}
                      >
                        <div
                          className={`w-8 h-8 ${service.isPopular ? "bg-red-accent/90" : "bg-primary/90"} rounded-lg flex items-center justify-center backdrop-blur-sm`}
                        >
                          <IconComponent className="h-4 w-4 text-white" />
                        </div>
                      </motion.div>
                    </div>

                    <CardHeader className="pb-2">
                      <CardTitle
                        className={`text-card-foreground group-hover:${service.isPopular ? "text-red-accent" : "text-primary"} transition-colors duration-300 text-base`}
                      >
                        <EditableText 
                          initialText={service.title}
                          className={`text-card-foreground group-hover:${service.isPopular ? "text-red-accent" : "text-primary"} transition-colors duration-300 text-base`}
                          tag="span"
                        />
                      </CardTitle>
                    </CardHeader>

                    <CardContent className="space-y-3">
                      <EditableText 
                        initialText={service.description}
                        className="text-sm text-muted-foreground leading-relaxed"
                        tag="p"
                        multiline
                      />

                      <motion.ul
                        className="space-y-1"
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 + 0.5 }}
                      >
                        {service.features.map(
                          (feature, featureIndex) => (
                            <motion.li
                              key={featureIndex}
                              className="text-xs text-muted-foreground flex items-center"
                              initial={{ x: -10, opacity: 0 }}
                              whileInView={{ x: 0, opacity: 1 }}
                              viewport={{ once: true }}
                              transition={{
                                delay:
                                  index * 0.1 +
                                  featureIndex * 0.05 +
                                  0.6,
                              }}
                            >
                              <motion.div
                                className={`w-1 h-1 ${service.isPopular ? "bg-red-accent" : "bg-primary"} rounded-full mr-2 flex-shrink-0`}
                                whileHover={{ scale: 1.5 }}
                                transition={{
                                  type: "spring",
                                  stiffness: 400,
                                }}
                              />
                              <EditableText 
                                initialText={feature}
                                className="text-xs text-muted-foreground"
                                tag="span"
                              />
                            </motion.li>
                          ),
                        )}
                      </motion.ul>

                      {/* View Details Button */}
                      <div className="pt-3">
                        <motion.div
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            className={`w-full ${service.isPopular ? "border-red-accent text-red-accent hover:bg-red-accent hover:text-white" : "border-primary text-primary hover:bg-primary hover:text-primary-foreground"} transition-all duration-300 group-hover:shadow-md text-xs`}
                            onClick={() => openModal(service)}
                          >
                            <EditableText 
                              initialText="View Details"
                              className="text-xs"
                              tag="span"
                            />
                            <motion.div
                              animate={{ x: [0, 3, 0] }}
                              transition={{
                                duration: 1.5,
                                repeat: Infinity,
                              }}
                            >
                              <ArrowRight className="ml-1 h-3 w-3" />
                            </motion.div>
                          </Button>
                        </motion.div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })
          ) : (
            <div className="col-span-full text-center py-12">
              <EditableText 
                initialText="No services found in this category."
                className="text-muted-foreground text-lg"
                tag="p"
              />
            </div>
          )}
        </motion.div>

        {/* Service Benefits */}
        <motion.div
          className="mt-16 grid md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {[
            {
              icon: "24/7",
              color: "red-accent",
              title: "Round-the-Clock Support",
              desc: "Get assistance whenever you need it with our dedicated support team.",
            },
            {
              icon: "ROI",
              color: "primary",
              title: "Guaranteed Results",
              desc: "We're committed to delivering measurable outcomes for your investment.",
            },
            {
              icon: "+",
              color: "gradient",
              title: "Scalable Solutions",
              desc: "Our services grow with your business, adapting to your evolving needs.",
            },
          ].map((benefit, index) => (
            <motion.div
              key={index}
              className="text-center group cursor-pointer"
              variants={cardVariants}
              whileHover={{ y: -3 }}
            >
              <motion.div
                className={`w-10 h-10 ${benefit.color === "gradient" ? "bg-gradient-to-r from-primary to-red-accent" : `bg-${benefit.color}`} rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform`}
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                <EditableText 
                  initialText={benefit.icon}
                  className={`${benefit.color === "red-accent" ? "text-white" : "text-black"} font-bold text-sm`}
                  tag="span"
                />
              </motion.div>
              <EditableText 
                initialText={benefit.title}
                className="font-semibold text-foreground mb-2 text-sm"
                tag="h4"
              />
              <EditableText 
                initialText={benefit.desc}
                className="text-muted-foreground text-xs leading-relaxed"
                tag="p"
                multiline
              />
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {isModalOpen && selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 backdrop-blur-sm bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={closeModal}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-card rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                {/* Header Image */}
                <div className="relative h-48 md:h-56 overflow-hidden">
                  <ImageWithFallback
                    src={selectedService.image}
                    alt={selectedService.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Close Button */}
                  <button
                    onClick={closeModal}
                    className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <Badge className={`${selectedService.categoryColor} border-0`}>
                      <EditableText 
                        initialText={selectedService.category}
                        className="text-xs"
                        tag="span"
                      />
                    </Badge>
                  </div>

                  {/* Popular Badge */}
                  {selectedService.isPopular && (
                    <div className="absolute top-4 right-16 bg-red-accent text-white px-3 py-1 rounded-full text-sm font-bold flex items-center">
                      <Star className="w-4 h-4 mr-1" />
                      <EditableText 
                        initialText="Popular"
                        className="text-sm font-bold text-white"
                        tag="span"
                      />
                    </div>
                  )}
                </div>

                {/* Modal Content */}
                <div className="p-6 md:p-8 h-120">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <EditableText 
                        initialText={selectedService.title}
                        className="text-2xl md:text-3xl font-bold text-card-foreground mb-2"
                        tag="h2"
                      />
                      <EditableText 
                        initialText={selectedService.description}
                        className="text-muted-foreground text-lg"
                        tag="p"
                        multiline
                      />
                    </div>
                    <div className={`w-12 h-12 ${selectedService.isPopular ? "bg-red-accent/20" : "bg-primary/20"} rounded-lg flex items-center justify-center ml-4`}>
                      {selectedService.icon && (
                        <selectedService.icon className={`w-6 h-6 ${selectedService.isPopular ? "text-red-accent" : "text-primary"}`} />
                      )}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-8 mb-8">
                    {/* Detailed Description */}
                    <div>
                      <EditableText 
                        initialText="Service Overview"
                        className="text-lg font-semibold text-card-foreground mb-4"
                        tag="h3"
                      />
                      <EditableText 
                        initialText={selectedService.detailedDescription}
                        className="text-muted-foreground leading-relaxed"
                        tag="p"
                        multiline
                      />
                    </div>

                    {/* Key Benefits */}
                    <div>
                      <EditableText 
                        initialText="Key Benefits"
                        className="text-lg font-semibold text-card-foreground mb-4"
                        tag="h3"
                      />
                      <ul className="space-y-3">
                        {selectedService.benefits.map((benefit, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                            <EditableText 
                              initialText={benefit}
                              className="text-muted-foreground"
                              tag="span"
                            />
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-6 mb-8">
                    {/* Process */}
                    <div>
                      <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                        <Clock className="w-5 h-5 mr-2" />
                        <EditableText 
                          initialText="Our Process"
                          className="text-lg font-semibold text-card-foreground"
                          tag="span"
                        />
                      </h3>
                      <ol className="space-y-2">
                        {selectedService.process.map((step, index) => (
                          <li key={index} className="text-muted-foreground text-sm">
                            <span className="font-semibold text-primary">{index + 1}.</span> 
                            <EditableText 
                              initialText={step}
                              className="text-muted-foreground text-sm ml-1"
                              tag="span"
                            />
                          </li>
                        ))}
                      </ol>
                    </div>

                    {/* Pricing */}
                    <div>
                      <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                        <DollarSign className="w-5 h-5 mr-2" />
                        <EditableText 
                          initialText="Pricing"
                          className="text-lg font-semibold text-card-foreground"
                          tag="span"
                        />
                      </h3>
                      <EditableText 
                        initialText={selectedService.pricing}
                        className="text-muted-foreground"
                        tag="p"
                      />
                    </div>

                    {/* Timeline */}
                    <div>
                      <h3 className="text-lg font-semibold text-card-foreground mb-4 flex items-center">
                        <Calendar className="w-5 h-5 mr-2" />
                        <EditableText 
                          initialText="Timeline"
                          className="text-lg font-semibold text-card-foreground"
                          tag="span"
                        />
                      </h3>
                      <EditableText 
                        initialText={selectedService.timeline}
                        className="text-muted-foreground"
                        tag="p"
                      />
                    </div>
                  </div>

                  {/* Features */}
                  <div className="mb-8">
                    <EditableText 
                      initialText="Core Features"
                      className="text-lg font-semibold text-card-foreground mb-4"
                      tag="h3"
                    />
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {selectedService.features.map((feature, index) => (
                        <div key={index} className="flex items-center text-sm text-muted-foreground">
                          <div className={`w-2 h-2 ${selectedService.isPopular ? "bg-red-accent" : "bg-primary"} rounded-full mr-2 flex-shrink-0`} />
                          <EditableText 
                            initialText={feature}
                            className="text-sm text-muted-foreground"
                            tag="span"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* CTA Section */}
                  <div className="text-center pt-6 border-t border-border">
                    <EditableText 
                      initialText="Ready to get started?"
                      className="text-lg font-semibold text-card-foreground mb-4"
                      tag="h3"
                    />
                    <EditableText 
                      initialText="Contact us today to discuss how this service can benefit your business."
                      className="text-muted-foreground mb-6"
                      tag="p"
                    />
                    <Button className={`${selectedService.isPopular ? "bg-red-accent hover:bg-red-accent/90" : "bg-primary hover:bg-primary/90"} text-white px-8 py-3`}>
                      <EditableText 
                        initialText="Get Started"
                        className="font-medium text-white"
                        tag="span"
                      />
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.section>
  );
}