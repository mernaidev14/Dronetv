
  # Modern Minimalistic Innovative Labs Website

  This is a code bundle for Modern Minimalistic Innovative Labs Website. The original project is available at https://www.figma.com/design/uPbN61uRhmRAI4KFl1VjQ4/Modern-Minimalistic-Innovative-Labs-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  